package com.ischoolbar.programmer.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ischoolbar.programmer.model.Page;
import com.ischoolbar.programmer.model.Student;
import com.ischoolbar.programmer.util.StringUtil;

public class StudentDao extends BaseDao {
	public boolean StudentAdd(Student student) {
		String sql = "insert into s_student values(null,'"+student.getSn()+"','"+student.getName()+"','"+student.getPassword()+"','"+student.getSex()+"','"
						+student.getClazzId()+"','"+student.getQq()+"','"+student.getMobile()+"',null)";
		boolean result = Update(sql);
					
		return result == true;
	}
	
	public boolean StudentDelete(String ids) {
		String sql ="delete from s_student where id in(" + ids+")";
		
		boolean reslut = Update(sql);
		StudentFreash();
	
		
		return reslut;
	}
	public void StudentFreash() {
		String freash = "alter table s_student  AUTO_INCREMENT=1";
		
		Update(freash);
		
	}
	
	public boolean StudentEdit(Student student) {
		String sql = "update s_student set name = '"+student.getName()+"'";
		sql += ",sex = '" + student.getSex() + "'";
		sql += ",mobile = '" + student.getMobile() + "'";
		sql += ",qq = '" + student.getQq() + "'";
		sql += ",clazz_id = " + student.getClazzId();
		sql += " where id = " + student.getId();
		
		return Update(sql);
		
	}
	public boolean setStudentPhoto(Student student) {
		String sql = "update s_student set photo = ? where id = ?";
		Connection connnection = getConnnection();
		try {
			PreparedStatement pstmt = connnection.prepareStatement(sql);
			pstmt.setBinaryStream(1, student.getPhoto());
			pstmt.setInt(2,student.getId());
			int count = pstmt.executeUpdate();
			return count>0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}
	
	public List<Student> getStudentList(Student student,Page page){
		String Sql = "select * from s_student ";
		
		if(!StringUtil.isEmpty(student.getName())) {
			Sql +=  "and name like '%"+student.getName()+"%'"; 
		}
		if(student.getClazzId()!=0) {
			Sql += "and clazz_id = " + student.getClazzId();
		}
		if(student.getId()!=0) {
			Sql += " and id = " + student.getId();
		}
		Sql += " limit " + page.getStart() + "," +page.getPageSize();
		ResultSet resultSet = query(Sql.replaceFirst("and", "where"));
		
		List<Student> arraylist = new ArrayList<Student>();//��ѧ�����������ñ�������
		try {
			while(resultSet.next()) {
				Student stu = new Student();
				stu.setId(resultSet.getInt("id"));
				stu.setName(resultSet.getString("name"));
				stu.setClazzId(resultSet.getInt("clazz_id"));
				stu.setMobile(resultSet.getString("mobile"));
				stu.setPassword(resultSet.getString("password"));
				stu.setQq(resultSet.getString("qq"));
				stu.setSex(resultSet.getString("sex"));
				stu.setSn(resultSet.getString("sn"));
				stu.setPhoto(resultSet.getBinaryStream("photo"));
				arraylist.add(stu);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return arraylist;
	}
	public Student getStudent(int id) {
		String sql = "select * from s_student where id = "+ id;
		ResultSet resultSet = query(sql);
		Student student = null;
		try {
			if(resultSet.next()) {
				student = new Student();
				student.setId(resultSet.getInt("id"));
				student.setClazzId(resultSet.getInt("clazz_id"));
				student.setMobile(resultSet.getString("mobile"));
				student.setName(resultSet.getString("name"));
				student.setPassword(resultSet.getString("password"));
				student.setPhoto(resultSet.getBinaryStream("photo"));
				student.setQq(resultSet.getString("qq"));
				student.setSex(resultSet.getString("sex"));
				student.setSn(resultSet.getString("sn"));
				return student;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}
	
	public int getStudentTotal(Student student){
		int total = 0;
		String Sql = "select count(*) as total from s_student ";
		if(!StringUtil.isEmpty(student.getName())) {
			Sql +=  "and name like '%"+student.getName()+"%'"; 
		}
		if(student.getClazzId() != 0){
			Sql += " and clazz_id = " + student.getClazzId();
		}
		if(student.getId() != 0){
			Sql += " and id = " + student.getId();
		}
		
		ResultSet result = query(Sql.replaceFirst("and", "where"));
		try {
			while(result.next()) {
				 total = result.getInt("total");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return total;

	}

	public Student login(String username, String password) {
		String sql = "select * from s_student where name = '"+username +"' and password = '"+password+"'";
		ResultSet resultSet = query(sql);
		try {
			if(resultSet.next()) {
				Student student = new Student();
				student.setId(resultSet.getInt("id"));
				student.setName(resultSet.getString("name"));
				student.setPassword(resultSet.getString("password"));
				student.setClazzId(resultSet.getInt("clazz_id"));
				student.setMobile(resultSet.getString("mobile"));
				student.setPhoto(resultSet.getBinaryStream("photo"));
				student.setQq(resultSet.getString("qq"));
				student.setSex(resultSet.getString("sex"));
				student.setSn(resultSet.getString("sn"));
				return student;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

	public boolean editPassword(Student student, String newPassword) {
		String sql = "update s_student set password = '"+newPassword+"' where id = "+student.getId();
		
		return Update(sql);
	}
	
}
