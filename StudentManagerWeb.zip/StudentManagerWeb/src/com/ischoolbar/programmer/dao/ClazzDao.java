package com.ischoolbar.programmer.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ischoolbar.programmer.model.Clazz;
import com.ischoolbar.programmer.model.Page;
import com.ischoolbar.programmer.util.StringUtil;



public class ClazzDao extends BaseDao {
	
	/**
	 * 
	 *@param clazz :�༶��
	 *@param page : ��ҳ�࣬
	 *@return ����ѯ��Ϣ��İ༶�෵��
	 *
	 *��ѯ�༶��ʼҳ��ҳ����Χ�ڵ�����
	 * 
	 * */
	public List<Clazz> getClazzList(Clazz clazz,Page page){
		String Sql = "select * from s_clazz ";
		
		if(!StringUtil.isEmpty(clazz.getName())) {
			Sql +=  "where name like '%"+clazz.getName()+"%'"; 
		}
		Sql += "limit " + page.getStart() + "," +page.getPageSize();
		ResultSet resultSet = query(Sql);
		
		List<Clazz> arraylist = new ArrayList<Clazz>();//���༶���������ñ�������
		try {
			while(resultSet.next()) {
				Clazz cl = new Clazz();
				cl.setId(resultSet.getInt("id"));
				cl.setName(resultSet.getString("name"));
				cl.setInfo(resultSet.getString("info"));
				arraylist.add(cl);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return arraylist;
	}
	
	public int getClazzTotal(Clazz clazz){
		int total = 0;
		String Sql = "select count(*) as total from s_clazz ";
		if(!StringUtil.isEmpty(clazz.getName())) {
			Sql +=  "where name like '%"+clazz.getName()+"%'"; 
		}
		
		ResultSet result = query(Sql);
		try {
			while(result.next()) {
				 total = result.getInt("total");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return total;

	}
	
	public boolean ClazzAdd(Clazz clazz) {
		String Sql = "insert into s_clazz values(null,'"+clazz.getName()+"','"+clazz.getInfo()+"');";
		boolean result =Update(Sql);
	
		return result == true;
		
	}
	
	public boolean Clazzdelete(int id) {
		String Sql = "delete from s_clazz where id = " + id;
		boolean result =Update(Sql);
	
		return result == true;
		
	}
	public boolean ClazzEdit(Clazz clazz) {
		String Sql = "update s_clazz set name = '"+clazz.getName()+"',info = '"+clazz.getInfo()+"' where id = "+clazz.getId();
		boolean result =Update(Sql);
	
		return result == true;
		
	}
}
