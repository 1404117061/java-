package com.ischoolbar.programmer.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ischoolbar.programmer.model.Page;
import com.ischoolbar.programmer.model.Student;
import com.ischoolbar.programmer.model.Teacher;
import com.ischoolbar.programmer.util.StringUtil;

public class TeacherDao extends BaseDao {
	public boolean TeachaerAdd(Teacher teacher) {
		String sql = "insert into s_teacher values(null,'"+teacher.getSn()+"','"+teacher.getName()+"','"+teacher.getPassword()+"','"+teacher.getSex()+"','"
						+teacher.getClazzId()+"','"+teacher.getQq()+"','"+teacher.getMobile()+"',null)";
		boolean result = Update(sql);
					
		return result == true;
	}
	public boolean TeacherEdit(Teacher teacher) {
		String sql = "update s_teacher set name = '"+teacher.getName()+"'";
		sql += ",sex = '" + teacher.getSex() + "'";
		sql += ",mobile = '" + teacher.getMobile() + "'";
		sql += ",qq = '" + teacher.getQq() + "'";
		sql += ",clazz_id = " + teacher.getClazzId();
		sql += " where id = " + teacher.getId();
		
		return Update(sql);
	}
	public boolean TeacherDelete(String ids) {
		String sql ="delete from s_teacher where id in(" + ids+")";
		
		boolean reslut = Update(sql);
		TeacherFreash();
	
		
		return reslut;
	}
	public void TeacherFreash() {
		String freash = "alter table s_teacher  AUTO_INCREMENT=1";
		
		Update(freash);
		
	}
	public Teacher login(String username, String password) {
		String sql = "select * from s_teacher where name = '"+username +"' and password = '"+password+"'";
		ResultSet resultSet = query(sql);
		try {
			if(resultSet.next()) {
				Teacher teacher = new Teacher();
				teacher.setId(resultSet.getInt("id"));
				teacher.setName(resultSet.getString("name"));
				teacher.setPassword(resultSet.getString("password"));
				teacher.setClazzId(resultSet.getInt("clazz_id"));
				teacher.setMobile(resultSet.getString("mobile"));
				teacher.setPhoto(resultSet.getBinaryStream("photo"));
				teacher.setQq(resultSet.getString("qq"));
				teacher.setSex(resultSet.getString("sex"));
				teacher.setSn(resultSet.getString("sn"));
				return teacher;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	
	public List<Teacher> getTeacherList(Teacher teacher,Page page){
		ArrayList<Teacher> arrayList = new ArrayList<Teacher>();
		String sql = "select * from s_teacher ";
		if(!StringUtil.isEmpty(teacher.getName())){
			sql += "and name like '%" + teacher.getName() + "%'";
		}
		if(teacher.getClazzId() != 0){
			sql += " and clazz_id = " + teacher.getClazzId();
		}
		if(teacher.getId() !=0 ){
			sql += " and id = " + teacher.getId();
		}
		sql += " limit " + page.getStart() + "," + page.getPageSize();
		ResultSet resultSet = query(sql.replaceFirst("and", "where"));
		try {
			while(resultSet.next()) {
				Teacher t = new Teacher();
				t.setId(resultSet.getInt("id"));
				t.setClazzId(resultSet.getInt("clazz_id"));
				t.setMobile(resultSet.getString("mobile"));
				t.setName(resultSet.getString("name"));
				t.setPassword(resultSet.getString("password"));
				t.setPhoto(resultSet.getBinaryStream("photo"));
				t.setQq(resultSet.getString("qq"));
				t.setSex(resultSet.getString("sex"));
				t.setSn(resultSet.getString("sn"));
				arrayList.add(t);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return arrayList;
		
	}
	public int getTeacherTotal(Teacher teacher){
		int total = 0;
		String Sql = "select count(*) as total from s_teacher ";
		if(!StringUtil.isEmpty(teacher.getName())) {
			Sql +=  "and name like '%"+teacher.getName()+"%'"; 
		}
		if(teacher.getClazzId() != 0){
			Sql += " and clazz_id = " + teacher.getClazzId();
		}
		if(teacher.getId() != 0){
			Sql += " and id = " + teacher.getId();
		}
	    Sql = Sql.replaceFirst("and", "where");
		ResultSet result = query(Sql);
		try {
			while(result.next()) {
				 total = result.getInt("total");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return total;

	}
	public boolean setTeacherPhoto(Teacher teacher) {
		String sql = "update s_teacher set photo = ? where id = ?";
		Connection connnection = getConnnection();
		try {
			PreparedStatement pstmt = connnection.prepareStatement(sql);
			pstmt.setBinaryStream(1, teacher.getPhoto());
			pstmt.setInt(2, teacher.getId());
			int count = pstmt.executeUpdate();
			return count > 0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
		
	}
	public Teacher getTeacher(int sid) {
		String sql = "select * from s_teacher where id = " + sid;
		ResultSet resultSet = query(sql);
		try {
			while(resultSet.next()) {
				Teacher t = new Teacher();			
				t.setId(resultSet.getInt("id"));
				t.setClazzId(resultSet.getInt("clazz_id"));
				t.setMobile(resultSet.getString("mobile"));
				t.setName(resultSet.getString("name"));
				t.setPassword(resultSet.getString("password"));
				t.setPhoto(resultSet.getBinaryStream("photo"));
				t.setQq(resultSet.getString("qq"));
				t.setSex(resultSet.getString("sex"));
				t.setSn(resultSet.getString("sn"));
				return t;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return null;
	}
	public boolean editPassword(Teacher teacher, String newPassword) {
		String sql = "update s_teacher set password = '"+newPassword+"' where id = "+teacher.getId();
		
		return Update(sql);
	}
	
}
