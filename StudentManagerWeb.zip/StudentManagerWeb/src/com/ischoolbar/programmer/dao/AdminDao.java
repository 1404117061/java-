package com.ischoolbar.programmer.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.ischoolbar.programmer.model.Admin;

public class AdminDao extends BaseDao{
	public Admin login(String username,String password) {
		//�������ݿ���"name"������Ϊ�ַ��ͣ�����ƴ��ʱ����Ҫ���ϵ�����''�����磺"select * from s_admin where name = 'admin'",������"select * from s_admin where name = admin"
		String sql = "select * from s_admin where name = '"+username+"'and password = '"+password+"'"; 
		ResultSet resultSet  = query(sql);
		try {
			if(resultSet.next()) {
				Admin admin = new Admin();			
				admin.setId(resultSet.getInt("id"));
				admin.setName(resultSet.getString("name"));
				admin.setPassword(resultSet.getString("password"));
				admin.setStatus(resultSet.getInt("status"));
				return admin;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
		
	}
	
	public boolean editPassword(Admin admin,String newPassword) {
		// TODO Auto-generated method stub
		String sql = "update s_admin set password = '"+newPassword+"' where id = " + admin.getId();
		return Update(sql);
	}
}
