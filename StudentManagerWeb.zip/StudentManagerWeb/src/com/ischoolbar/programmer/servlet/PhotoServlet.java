package com.ischoolbar.programmer.servlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileUploadException;

import com.ischoolbar.programmer.dao.StudentDao;
import com.ischoolbar.programmer.dao.TeacherDao;
import com.ischoolbar.programmer.model.Student;
import com.ischoolbar.programmer.model.Teacher;
import com.lizhou.exception.FileFormatException;
import com.lizhou.exception.NullFileException;
import com.lizhou.exception.ProtocolException;
import com.lizhou.exception.SizeException;
import com.lizhou.fileload.FileUpload;

public class PhotoServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		doPost(request,response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		String method = request.getParameter("method");
		if("getPhoto".equals(method)) {
			getPhoto(request, response);
		}else if("SetPhoto".equals(method)) {
			setPhoto(request,response);
		}
		
		
		
		
	}
	private void setPhoto(HttpServletRequest request, HttpServletResponse response) {
		int sid = request.getParameter("sid") == null ? 0 : Integer.parseInt(request.getParameter("sid"));
		int tid = request.getParameter("tid") == null ? 0 : Integer.parseInt(request.getParameter("tid"));
		FileUpload fileUpload = new FileUpload(request); //�����ļ������������������ļ�
	
		fileUpload.setFileFormat("jpg");	//����ͼƬ��ʽ
		fileUpload.setFileFormat("png");
		fileUpload.setFileFormat("jpeg");
		fileUpload.setFileFormat("gif");  
		fileUpload.setFileSize(2048);    //����ͼƬ��СΪ2048kb
		response.setCharacterEncoding("UTF-8");  //���ñ����ʽ
		try {
			InputStream photo = fileUpload.getUploadInputStream();  // ��ȡͼƬ�ֽ���
			if(sid!=0) {
				StudentDao studentDao = new StudentDao();				
				Student student = new Student();
				student.setId(sid);
				student.setPhoto(photo);
				boolean result = studentDao.setStudentPhoto(student);
				studentDao.closecon();
				if(result){
					response.getWriter().write("<div id='message'>�ϴ��ɹ���</div>");
				}else{
					response.getWriter().write("<div id='message'>�ϴ�ʧ�ܣ�</div>");
				}
			}else if(tid!=0) {
				Teacher teacher = new Teacher();
				teacher.setId(tid);
				teacher.setPhoto(photo);
				TeacherDao teacherDao = new TeacherDao();
				boolean result = teacherDao.setTeacherPhoto(teacher);
				teacherDao.closecon();
				if(result) {
					response.getWriter().write("<div id='message'>�ϴ��ɹ���</div>");
				}else{
					response.getWriter().write("<div id='message'>�ϴ�ʧ�ܣ�</div>");
				}
			}
			
		} catch (ProtocolException e) {
			// TODO Auto-generated catch block
			try {
				response.getWriter().write("<div id='message'>�ϴ�Э�����</div>");
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		}catch (NullFileException e1) {
			// TODO: handle exception
			try {
				response.getWriter().write("<div id='message'>�ϴ����ļ�Ϊ��!</div>");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			e1.printStackTrace();
		}
		catch (SizeException e2) {
			// TODO: handle exception
			try {
				response.getWriter().write("<div id='message'>�ϴ��ļ���С���ܳ���"+fileUpload.getFileSize()+"KB��</div>");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			e2.printStackTrace();
		}
		catch (IOException e3) {
			// TODO: handle exception
			try {
				response.getWriter().write("<div id='message'>��ȡ�ļ�������</div>");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			e3.printStackTrace();
		}
		catch (FileFormatException e4) {
			// TODO: handle exception
			try {
				response.getWriter().write("<div id='message'>�ϴ��ļ���ʽ����ȷ�����ϴ� "+fileUpload.getFileFormat()+" ��ʽ���ļ���</div>");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			e4.printStackTrace();
		}
		catch (FileUploadException e5) {
			// TODO: handle exception
			try {
				response.getWriter().write("<div id='message'>�ϴ��ļ�ʧ�ܣ�</div>");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			e5.printStackTrace();
		}
		
		
	}
	private void getPhoto(HttpServletRequest request, HttpServletResponse response) {
		int sid = request.getParameter("sid") == null ? 0:Integer.parseInt(request.getParameter("sid"));
		int tid = request.getParameter("tid") == null ? 0:Integer.parseInt(request.getParameter("tid"));
		if(sid != 0) {
			StudentDao studentDao = new StudentDao();
			Student student = studentDao.getStudent(sid);
			studentDao.closecon();
			InputStream photo = student.getPhoto();
			if(photo != null) {

				OutputImagePhoto(response, photo);
				
			}
			return;
			
		}else if(tid != 0) {
		
			TeacherDao teacherDao = new TeacherDao();
			Teacher teacher = teacherDao.getTeacher(tid); //��ȡͼƬ�ֽ���
			teacherDao.closecon();
			InputStream photo = teacher.getPhoto();
			if(photo != null) {

				OutputImagePhoto(response, photo);
				
			}
			return;
			
		}
		//����Ա��½ʱ����ʾ��ͼƬ
		File file = new File("qq1.jpg");
		String path = request.getSession().getServletContext().getRealPath("") +"\\file\\qq1.jpg" ;
		OutputImagePath(path,response);
	}
	
	
	private void OutputImagePhoto(HttpServletResponse response, InputStream photo) {
		byte[] bys = new byte[1024];
		int i ;
		try {
			ServletOutputStream outputStream = response.getOutputStream();
			while((i=photo.read(bys))!=-1) {
				outputStream.write(bys,0,i);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public void OutputImagePath(String path,HttpServletResponse response) {
		ServletOutputStream output;
		try {
			output = response.getOutputStream();
			FileInputStream fis = new FileInputStream(path);
			byte[] bys = new byte[1024];
			int i;
			while((i=fis.read(bys)) != -1) {
				output.write(bys,0,i);
			}
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
	}
	
}
