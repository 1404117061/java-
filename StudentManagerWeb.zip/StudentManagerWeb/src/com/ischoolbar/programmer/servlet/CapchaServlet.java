package com.ischoolbar.programmer.servlet;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ischoolbar.programmer.util.CapchaUtil;

public class CapchaServlet extends HttpServlet{
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException {
		doPost(request,response);
		
		
	}
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException {
		String method = request.getParameter("method");  //�������url�л�ȡmethod��ֵ
		if("loginCapcha".equals(method)) {
			generateLoginCpacha(request,response);
			return;
		}
		response.getWriter().write("capchacode error");
	}
	private void generateLoginCpacha(HttpServletRequest request,HttpServletResponse reponse) throws IOException {
		CapchaUtil capchaUtil = new CapchaUtil();  //����ͼ����֤��ʵ��
		String generatorVCode = capchaUtil.generatorVCode(); //������֤��
		BufferedImage generatorRotateVCodeImage = capchaUtil.generatorRotateVCodeImage(generatorVCode, true); //������֤��ͼƬ
		ImageIO.write(generatorRotateVCodeImage, "gif", reponse.getOutputStream()); //���ͼ��
		
		request.getSession().setAttribute("loginCapcha", generatorVCode);//����֤�뱣����session�У��Ա��ж��Ƿ���ȷ
	
	}
	
}
