package com.ischoolbar.programmer.servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ischoolbar.programmer.dao.TeacherDao;
import com.ischoolbar.programmer.model.Page;
import com.ischoolbar.programmer.model.Teacher;

import net.sf.json.JSONObject;

public class TeacherServlet extends HttpServlet {

	
	private static final long serialVersionUID = 1L;
	
	public void doGet(HttpServletRequest request,HttpServletResponse response) {
		doPost(request,response);
	}
	
	public void doPost(HttpServletRequest request,HttpServletResponse response) {
		String method = request.getParameter("method");
		if("toTeacherListView".equals(method)) {
			teacherList(request,response);
		}else if("AddTeacher".equals(method)) {
			teacherAdd(request,response);
		}else if("TeacherList".equals(method)){
			getTeacherList(request,response);
		}else if("EditTeacher".equals(method)){
			editTeacher(request,response);
		}else if("DeleteTeacher".equals(method)) {
			deleteTeacher(request,response);
		}
	}

	private void deleteTeacher(HttpServletRequest request, HttpServletResponse response) {
		String[] ids = request.getParameterValues("ids[]");
		String sql = "";
		for(String i : ids) {
			sql += i + ",";
		}
		TeacherDao teacherDao = new TeacherDao();
		boolean result = teacherDao.TeacherDelete(sql.substring(0, sql.length()-1));
		if(result) {
			try {
				response.getWriter().write("success");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
		
	}

	private void editTeacher(HttpServletRequest request, HttpServletResponse response) {
		String name = request.getParameter("name");
		String phone = request.getParameter("mobile");
		String qq = request.getParameter("qq");
		String sex = request.getParameter("sex");
		int clazzid = Integer.parseInt(request.getParameter("clazzid"));
		int id = Integer.parseInt(request.getParameter("id"));
		
		Teacher teacher = new Teacher();
		teacher.setName(name);
		teacher.setMobile(phone);
		teacher.setQq(qq);
		teacher.setSex(sex);
		teacher.setClazzId(clazzid);
		teacher.setId(id);
		TeacherDao teacherDao = new TeacherDao();
		boolean reslut = teacherDao.TeacherEdit(teacher);
		if(reslut) {
			try {
				response.getWriter().write("success");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

	private void getTeacherList(HttpServletRequest request, HttpServletResponse response) {
		String name = request.getParameter("teacherName");
		int clazzId = request.getParameter("clazzid") == null ? 0 : Integer.parseInt(request.getParameter("clazzid"));
		int currentPage  = request.getParameter("page") == null? 1:Integer.parseInt(request.getParameter("page"));
		int pageSize = request.getParameter("rows") == null? 999: Integer.parseInt(request.getParameter("rows"));
		int userType = (int) request.getSession().getAttribute("userType");
		
		Teacher teacher = new Teacher();
		teacher.setName(name);
		teacher.setClazzId(clazzId);
		
		TeacherDao teacherDao = new TeacherDao();
		Page page = new Page(currentPage,pageSize);
		if(userType == 3) {
		Teacher currentTeacher=(Teacher)request.getSession().getAttribute("user");
		teacher.setId(currentTeacher.getId());
		}
		
		List<Teacher> teacherList = teacherDao.getTeacherList(teacher, page);
		
		int total = teacherDao.getTeacherTotal(teacher);
		
		response.setCharacterEncoding("UTF-8");
		HashMap<String, Object> hs = new HashMap<String,Object>();
		hs.put("total", total);
		hs.put("rows", teacherList);
		
		try {
				response.getWriter().write(JSONObject.fromObject(hs).toString());
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		
	}


	private void teacherAdd(HttpServletRequest request, HttpServletResponse response) {
		String name = request.getParameter("name");
		String password = request.getParameter("password");
		String sn = request.getParameter("sn");
		String sex = request.getParameter("sex");
		String mobile = request.getParameter("mobile");
		String qq = request.getParameter("qq");
		int clazzid = Integer.parseInt(request.getParameter("clazzid"));
		
		Teacher teacher = new Teacher();
		teacher.setClazzId(clazzid);
		teacher.setMobile(mobile);
		teacher.setName(name);
		teacher.setPassword(password);
		teacher.setQq(qq);
		teacher.setSex(sex);
		teacher.setSn(sn);
		
		TeacherDao teacherDao = new TeacherDao();
		boolean result = teacherDao.TeachaerAdd(teacher);
		
		if(result) {
			try {
				response.getWriter().write("success");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

	private void teacherList(HttpServletRequest request, HttpServletResponse response) {
		try {
			request.getRequestDispatcher("view/teacherList.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
