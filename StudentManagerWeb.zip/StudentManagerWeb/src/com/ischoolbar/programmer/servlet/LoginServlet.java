package com.ischoolbar.programmer.servlet;

import java.io.IOException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ischoolbar.programmer.dao.AdminDao;
import com.ischoolbar.programmer.dao.StudentDao;
import com.ischoolbar.programmer.dao.TeacherDao;
import com.ischoolbar.programmer.model.Admin;
import com.ischoolbar.programmer.model.Student;
import com.ischoolbar.programmer.model.Teacher;
import com.ischoolbar.programmer.util.StringUtil;

public class LoginServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException {
		doPost(request,response);
		
	}
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException {
		String method = request.getParameter("method");
		/*
		 * ����û��ǳ��������logout�������ض��򵽵�¼ҳ
		 * 
		 * */
		if(method.equals("logout")) {
			logout(request,response);
			return;
		}
		
		String vcode = request.getParameter("vcode");//��ȡǰ��ҳ�����֤��
		String loginCapcha = (String) request.getSession().getAttribute("loginCapcha"); //��ȡ��ȷ����֤��
		int type = Integer.parseInt(request.getParameter("type"));  //��¼������
		String username = request.getParameter("account");
		String password = request.getParameter("password");
		

		/*
		 * �ж���֤���Ƿ�ϸ�
		 * */
		if (StringUtil.isEmpty(vcode)) {
			response.getWriter().write("vcodeError");
			return; 
		}
		if (!vcode.toUpperCase().equals(loginCapcha.toUpperCase())) {
			response.getWriter().write("vcodeError");
			return;
		}
		/*
		 * �жϵ�¼�����ͣ��Լ��û��Ƿ����
		 * 
		 * */
		String loginStatus ="loginFaild";
		switch(type) {	
			case 1:{
				AdminDao adminDao = new AdminDao();
				Admin admin = adminDao.login(username, password);
				adminDao.closecon(); // �ر����ӣ��ͷ���Դ
				if(admin == null) {
					response.getWriter().write("loginError");
					return;
				}
				
				loginStatus = "loginSuccess";
				request.getSession().setAttribute("user", admin);
				request.getSession().setAttribute("userType", type);
				break;
			}
			case 2:{
				StudentDao studentDao = new StudentDao();
				Student student = studentDao.login(username, password);
				studentDao.closecon(); // �ر����ӣ��ͷ���Դ
				if(student == null) {
					response.getWriter().write("loginError");
					return;
				}
				
				loginStatus = "loginSuccess";
				request.getSession().setAttribute("user", student);
				request.getSession().setAttribute("userType", type);
				break;
			}
			case 3:{
				TeacherDao teacherDao = new TeacherDao();
				Teacher teacher = teacherDao.login(username, password);
				teacherDao.closecon(); // �ر����ӣ��ͷ���Դ
				if(teacher == null) {
					response.getWriter().write("loginError");
					return;
				}
				
				loginStatus = "loginSuccess";
				request.getSession().setAttribute("user", teacher);
				request.getSession().setAttribute("userType", type);
				break;
			}
		
		}
		response.getWriter().write(loginStatus);
		
	}
	
	
	public void logout(HttpServletRequest request,HttpServletResponse response) throws IOException {
		request.getSession().removeAttribute("user");
		request.getSession().removeAttribute("userType");
		response.sendRedirect("index.jsp");
		
		
	}
}
