package com.ischoolbar.programmer.servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ischoolbar.programmer.dao.ClazzDao;
import com.ischoolbar.programmer.model.Clazz;
import com.ischoolbar.programmer.model.Page;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;

public class ClazzServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) {
		doPost(request,response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) {
		String method = request.getParameter("method");
		if(method.equals("toClazzListView")) {
			clazzList(request,response);
		}else if(method.equals("getClazzList")) {
			getClazzList(request,response);
		}else if(method.equals("AddClazz")) {
			addClazz(request, response);
		}else if(method.equals("DeleteClazz")) {
			deleteClazz(request, response);
		}else if(method.equals("EditClazz")) {
			editClazz(request,response);
		}
		
	}
	
	
	
	private void editClazz(HttpServletRequest request, HttpServletResponse response) {
		Integer id = Integer.parseInt(request.getParameter("id"));
		String name = request.getParameter("name");
		String info = request.getParameter("info");
		
		Clazz clazz = new Clazz();
		clazz.setId(id);
		clazz.setInfo(info);
		clazz.setName(name);
		
		ClazzDao clazzDao = new ClazzDao();
		boolean result = clazzDao.ClazzEdit(clazz);
		
		if(result) {
			try {
				response.getWriter().write("success");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
				clazzDao.closecon();
			}
		}
		
	}
	private void deleteClazz(HttpServletRequest request, HttpServletResponse response) {
		String status = "Failed";
		Integer id = Integer.parseInt(request.getParameter("clazzid"));
		ClazzDao clazzDao = new ClazzDao();
		boolean clazzdelete = clazzDao.Clazzdelete(id);
		if(clazzdelete) {
			status = "success";
		}
		
		try {
			response.getWriter().write(status);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			clazzDao.closecon();
		}
		
	}
	private void addClazz(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		String status ="Failed";
		String name = request.getParameter("name");
		String info = request.getParameter("info");
		
		Clazz clazz = new Clazz();
		clazz.setName(name);
		clazz.setInfo(info);
		
		 ClazzDao clazzDao = new ClazzDao();
		 boolean clazzAdd = clazzDao.ClazzAdd(clazz);
		 if(clazzAdd) {
			 status="success";
		 }

		 try {
			response.getWriter().write(status);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			clazzDao.closecon();
		}
		
	}
	public void getClazzList(HttpServletRequest request, HttpServletResponse response) {
		String name = request.getParameter("clazzName");
		Integer currentPage = request.getParameter("page")==null ? 1:Integer.parseInt(request.getParameter("page")); //��ǰ�˻�ȡ��ǰҳ�Ĳ���
		Integer pageSize = request.getParameter("rows")==null ? 999:Integer.parseInt(request.getParameter("rows"));   //��ǰ�˻�ȡҳ����Χ
		
		Clazz clazz = new Clazz();
		clazz.setName(name);
		
		Page page = new Page(currentPage,pageSize); 
		
		ClazzDao clazzDao = new ClazzDao();
		List<Clazz> clazzList = clazzDao.getClazzList(clazz, page); //��ȡ�༶�б���Ϣ
		int total = clazzDao.getClazzTotal(clazz);  //��ȡ�༶����
		
		Map<String,Object> hs = new HashMap<String,Object>();
		hs.put("total", total);
		hs.put("rows",clazzList);
		
		response.setCharacterEncoding("UTF-8"); //���ñ����ʽ����ֹ����
		clazzDao.closecon();
		
//		JsonConfig jsonConfig = new JsonConfig();
//		String classListString = JSONArray.fromObject(clazzList, jsonConfig).toString();
//		System.out.println(classListString);
//		String json_data = JSONObject.fromObject(hs).toString(); 
		


		
		try {
			String from = request.getParameter("from") ;
			if("combox".equals(from)) {
				response.getWriter().write(JSONArray.fromObject(clazzList).toString());
				
			}else {
				response.getWriter().write(JSONObject.fromObject(hs).toString());
			}
			
		
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	
	
	
	
	/*
	 * ��ת���༶�б�ҳ
	 * */
	public void clazzList(HttpServletRequest request, HttpServletResponse response) {
		try {
			request.getRequestDispatcher("view/clazzList.jsp").forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		};
	}
	
	
}

