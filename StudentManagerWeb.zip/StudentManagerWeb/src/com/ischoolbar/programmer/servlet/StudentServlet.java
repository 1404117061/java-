package com.ischoolbar.programmer.servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ischoolbar.programmer.dao.ClazzDao;
import com.ischoolbar.programmer.dao.StudentDao;
import com.ischoolbar.programmer.model.Clazz;
import com.ischoolbar.programmer.model.Page;
import com.ischoolbar.programmer.model.Student;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class StudentServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request,HttpServletResponse response) {
		doPost(request,response);
	}
	
	public void doPost(HttpServletRequest request,HttpServletResponse response) {
		String method = request.getParameter("method");
		if("toStudentListView".equals(method)) {
			StudentList(request,response);
		}else if ("AddStudent".equals(method)){
			AddStuent(request,response);
		}else if("StudentList".equals(method)){
			getStudentList(request,response);
		}else if("EditStudent".equals(method)) {
			EditStudent(request,response);
		}else if("DeleteStudent".equals(method)) {
			DeleteStudetn(request,response);
		}
	}

	private void DeleteStudetn(HttpServletRequest request, HttpServletResponse response) {
		String[] ids = request.getParameterValues("ids[]");
		String str = "";
		for(String id : ids) {
			str += id + ",";
		}
		String idStr = str.substring(0, str.length()-1);
		StudentDao studentDao = new StudentDao();
		boolean result = studentDao.StudentDelete(idStr);
		if(result) {
			try {
				response.getWriter().write("success");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
				
				studentDao.closecon();
			}
		}
		
		
	}

	private void EditStudent(HttpServletRequest request, HttpServletResponse response) {
		String name = request.getParameter("name");
		String sex = request.getParameter("sex");
		String mobile = request.getParameter("mobile");
		String qq = request.getParameter("qq");
		int clazzid = Integer.parseInt(request.getParameter("clazzid"));
		int id = Integer.parseInt(request.getParameter("id"));
		
		Student student = new Student();
		student.setName(name);
		student.setSex(sex);
		student.setMobile(mobile);
		student.setQq(qq);
		student.setClazzId(clazzid);
		student.setId(id);
		StudentDao studentDao = new StudentDao();
		boolean result = studentDao.StudentEdit(student);
		
		
		try {
			if(result) {
				response.getWriter().write("success");
			}else {
				response.getWriter().write("faild");
			}		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			studentDao.closecon();
		}
		
		
		
	}

	private void getStudentList(HttpServletRequest request, HttpServletResponse response) {
		String name = request.getParameter("studentName");
		Integer currentPage = request.getParameter("page") == null ? 1 : Integer.parseInt(request.getParameter("page"));
		Integer pageSize = request.getParameter("rows") == null ? 999 : Integer.parseInt(request.getParameter("rows"));
		Integer clazz = request.getParameter("clazzid") == null ? 0 : Integer.parseInt(request.getParameter("clazzid"));
		int userType = (int) request.getSession().getAttribute("userType");
	
		Student student = new Student();
		student.setName(name);
		student.setClazzId(clazz);
		if(userType == 2){
			//�����ѧ����ֻ�ܲ鿴�Լ�����Ϣ
			Student currentUser = (Student)request.getSession().getAttribute("user");
			student.setId(currentUser.getId());
		}
		
		Page page = new Page(currentPage,pageSize); 
		StudentDao studentdao = new StudentDao();
		List<Student> studentList = studentdao.getStudentList(student, page); //��ȡ�༶�б���Ϣ
		int total = studentdao.getStudentTotal(student);  //��ȡ�༶����

		Map<String,Object> hs = new HashMap<String,Object>();
		hs.put("total", total);
		hs.put("rows",studentList);
		
		response.setCharacterEncoding("UTF-8"); //���ñ����ʽ����ֹ����
		
		
		try {
				response.getWriter().write(JSONObject.fromObject(hs).toString());
		
		} catch (IOException e) {
			
			e.printStackTrace();
		}finally {
			studentdao.closecon();
		}
	}
	

	private void AddStuent(HttpServletRequest request, HttpServletResponse response) {
		String name = request.getParameter("name");
		String sn = request.getParameter("sn");
		String password = request.getParameter("password");
		String sex = request.getParameter("sex");
		String mobile = request.getParameter("mobile");
		String qq = request.getParameter("qq");
		int clazzid = Integer.parseInt(request.getParameter("clazzid"));
		
		Student student = new Student();
		student.setName(name);
		student.setSn(sn);
		student.setPassword(password);
		student.setSex(sex);
		student.setMobile(mobile);
		student.setQq(qq);
		student.setClazzId(clazzid);
		
		StudentDao studentDao = new StudentDao();
		boolean studentAdd = studentDao.StudentAdd(student);
		if(studentAdd) {
			try {
				response.getWriter().write("success");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally {
				studentDao.closecon();
			}
		}
	}

	private void StudentList(HttpServletRequest request, HttpServletResponse response) {
		
		try {
			request.getRequestDispatcher("/view/studentList.jsp").forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		};
	}
}
