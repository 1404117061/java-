package com.ischoolbar.programmer.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ischoolbar.programmer.dao.AdminDao;
import com.ischoolbar.programmer.dao.StudentDao;
import com.ischoolbar.programmer.dao.TeacherDao;
import com.ischoolbar.programmer.model.Admin;
import com.ischoolbar.programmer.model.Student;
import com.ischoolbar.programmer.model.Teacher;

public class SystemServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException  {
		doPost(request,response);
		
	}
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException {
		String method = request.getParameter("method");
		if("toPersonalView".equals(method)) {
			toPersonalView(request,response);
			return;
		}else if("EditPassword".equals(method)) {
			editPassword(request,response);
			return;
		}
		
		try {
			request.getRequestDispatcher("/view/system.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private void editPassword(HttpServletRequest request, HttpServletResponse response) {
		String oldPassword = request.getParameter("password");
		String newPassword = request.getParameter("newpassword");
		int usertype = (int) request.getSession().getAttribute("userType");
		response.setCharacterEncoding("UTF-8");
		if(usertype ==1) {
			Admin admin = (Admin) request.getSession().getAttribute("user"); //ǿתΪAdmin����
			if(!oldPassword.equals(admin.getPassword())) {
				try {
					response.getWriter().write("ԭ�������");
					return;
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			AdminDao adminDao = new AdminDao();
			boolean result = adminDao.editPassword(admin, newPassword);
			if(result) {
				try {
					response.getWriter().write("success");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else {
				try {
					response.getWriter().write("���ݿ��޸Ĵ���");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		}else if(usertype == 2) {
			Student student = (Student) request.getSession().getAttribute("user"); //ǿתΪAdmin����
			if(!oldPassword.equals(student.getPassword())) {
				try {
					response.getWriter().write("ԭ�������");
					return;
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			StudentDao studentDao = new StudentDao();
			boolean result = studentDao.editPassword(student, newPassword);
			if(result) {
				try {
					response.getWriter().write("success");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else {
				try {
					response.getWriter().write("���ݿ��޸Ĵ���");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		else if(usertype == 3) {
			Teacher teacher = (Teacher) request.getSession().getAttribute("user"); //ǿתΪteacher����
			if(!oldPassword.equals(teacher.getPassword())) {
				try {
					response.getWriter().write("ԭ�������");
					return;
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			TeacherDao teacherDao = new TeacherDao();
			boolean result = teacherDao.editPassword(teacher, newPassword);
			if(result) {
				try {
					response.getWriter().write("success");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else {
				try {
					response.getWriter().write("���ݿ��޸Ĵ���");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
	}
	private void toPersonalView(HttpServletRequest request, HttpServletResponse response) {
		try {
			request.getRequestDispatcher("/view/personalView.jsp").forward(request, response);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
